import 'bootstrap';
import './components/navbar';
import './components/portfolio';
import './modules/swipe';
